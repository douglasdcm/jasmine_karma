class Car {
  constructor(name, year) {
    this.name = name;
    this.year = year;
  }
  run() {
    return 1;
  }
}

module.exports = Car