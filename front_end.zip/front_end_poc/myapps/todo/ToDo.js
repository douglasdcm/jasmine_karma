class ToDo {
  constructor() {
    this.todo = []
  }

  add(item) {
    this.todo.push(item)
  }

  getItems() {
    return this.todo
  }
}

module.exports = ToDo